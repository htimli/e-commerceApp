package e_commerce.application;



import e_commerce.domaine.Basket;
import e_commerce.domaine.BasketRepository;
import e_commerce.domaine.Reference;

public class AddProductCommand extends Command {
	
	private Reference ref;
	private int idBasket;
	private int quantite;
	private BasketRepository repository ;
	
	public AddProductCommand(Reference ref,int idBasket ,BasketRepository repository,int quantite)
	{
		this.idBasket=idBasket;
		this.repository = repository;
		this.ref=ref;
		this.quantite=quantite;
	}
	
	@Override
	public void execute() {	
		Basket basket =repository.findById(idBasket);
		basket.addReference(ref, quantite);
		repository.update(basket);		
	}

}
