package e_commerce.application;

import e_commerce.domaine.Basket;

public class PanierFactory {
	
	public Basket createBasket() {
		return new Basket();
	}
	

}
