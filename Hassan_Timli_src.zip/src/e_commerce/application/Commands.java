package e_commerce.application;

import java.util.ArrayList;
import java.util.List;

public class Commands {
	
	
	private List<Command> list ;
	
	
	public Commands() {
		this.list= new ArrayList<>();
	}
	
	public void pushCommand(Command newcommand){
		synchronized (this) {
			this.list.add(newcommand);	
		}				
	}
	public Command getCommand() {
			return this.list.remove(0);	
	}
	public Boolean isEmpty() {
		return this.list.isEmpty();
	}
	
	

}
