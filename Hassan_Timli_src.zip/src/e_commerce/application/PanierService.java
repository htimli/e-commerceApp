package e_commerce.application;

import java.util.Set;

import e_commerce.domaine.*;

public class PanierService {
	
	private PanierFactory factory ;
	private BasketRepository repository ;
	private Commands commands;
	private Worker worker;
	
	public PanierService(BasketRepository basketRepository) {
		
		this.factory = new PanierFactory();
		this.repository = basketRepository;
		this.commands = new Commands();
		this.worker= new Worker(commands);
		this.worker.start();
		
	}
	
	//commande
	public int createNewBasket() { 
		Basket basket = factory.createBasket() ;
		repository.save(basket);
		return basket.getId();		
	}
	//commande
	public void deleteBasket(int id) {
		 Basket basket = repository.findById(id);
		 if(basket!=null) {
			 repository.delete(basket);
		 }
	}
	//commande
	public void add_product_to_basket(int basketId,Reference ref,int quantite) {		
		this.commands.pushCommand(new AddProductCommand(ref, basketId, repository, quantite));
	}
	//commande
	public void remove_product_in_basket(int basketId,Reference ref) {
		Basket basket = repository.findById(basketId);
		basket.removeReference(ref);
		repository.update(basket);
	}
	//query
	public Set<LineBasket> get_All_products_in_basket(int basketId){
		Basket basket = repository.findById(basketId);
		return basket.getLines_commandes();
		
		
	}
	
	
	
	
}
