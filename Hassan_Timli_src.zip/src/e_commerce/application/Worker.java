package e_commerce.application;

public class Worker extends Thread {
	
	private Commands commands;
	
	
	public Worker(Commands commands) {
		this.commands=commands;
	}
	
	public void run() {
		while(true) {
			synchronized (commands) {
				if(!commands.isEmpty()) {
					Command command = this.commands.getCommand();
					command.execute();	
				}
			}	
		}			
	}
	


}
