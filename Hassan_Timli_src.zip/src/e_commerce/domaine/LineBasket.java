/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package e_commerce.domaine;

/**
 *
 * @author htimli
 */
public class LineBasket {
    
    private Reference reference;
    private int quantitee;
    private int montant;

    
    public LineBasket(Reference reference, int quantitee) {
        this.reference = reference;
        this.quantitee= quantitee;
        this.montant=this.quantitee*this.reference.getPrix();
    }

    public LineBasket(Reference reference) {
        this.reference = reference;
        
    }
    

    //hashset implementer equals et hashCode
    
    @Override
    public boolean equals(Object obj) {
       if(!(obj instanceof LineBasket )||obj == null)
           return false;   
       
       LineBasket other = (LineBasket)obj;
       
       return this.reference.equals(other.reference); 
        
    }
   
    @Override
    public int hashCode() {
        return reference.hashCode();
    }
    public void addQuantite(int quantitee){
        this.quantitee=this.quantitee+quantitee;
        this.montant=this.quantitee*this.montant;
    } 

    public int getMontant() {
        return montant;
    }

    @Override
    public String toString() {
        return "\n  -LineBasket{" + "reference=" + reference + ", quantit\u00e9=" + quantitee + ", montant=" + montant + '}';
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
