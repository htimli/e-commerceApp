

package e_commerce.domaine;

//Value Object




public class Reference {
    
    private final String REF;
    private final String NOM ;
    private final String  DESCRIPTION;
    private final int PRIX ;
    //regexp

    
    
    public Reference(String ref, String nom, String description, int prix) {
        this.REF = ref;
        this.NOM = nom;
        this.DESCRIPTION = description;
        this.PRIX = prix;
    }

    public String getRef() {
        return REF;
    }

    public String getNom() {
        return NOM;
    }

    public String getDescription() {
        return DESCRIPTION;
    }

    public int getPrix() {
        return PRIX;
    }

    @Override
    public String toString() {
        return "{" + "REF=" + REF + ", NOM=" + NOM + ", DESCRIPTION=" + DESCRIPTION + ", PRIX=" + PRIX + '}';
    }

   
    

    
}

